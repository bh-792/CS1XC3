/**
 * @file course.h
 * @author Bob He
 * @brief
 * @version 0.1
 * @date 2022-04-10
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Typedef for course type. Has fields with name, course code, student list and number of students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< Course name */
  char code[10]; /**< Course code */
  Student *students; /**< Students */
  int total_students; /**< Number of students  */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);