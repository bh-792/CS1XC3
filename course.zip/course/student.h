/**
 * @file student.h
 * @author Bob He
 * @brief
 * @version 0.1
 * @date 2022-04-10
 */

/**
 * @brief Typedef for student type. Has fields with first name, last name, student id, list of grades, and number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< First name */
  char last_name[50]; /**< Last name */
  char id[11]; /**< Student ID */
  double *grades; /**< Student grades */
  int num_grades; /**< Number of student grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
