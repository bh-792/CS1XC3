/**
 * @file course.c
 * @author Bob He
 * @brief
 * @version 0.1
 * @date 2022-04-10
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * @brief Enrolls a student into a course.
 *
 * @param course The course the student is to be enrolled in.
 * @param student The student that is enrolling.
 */
void enroll_student(Course *course, Student *student)
{
  
  course->total_students++;

  // If there is only one student in the course, then
  // allocate a space for the student.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
   
  // If there are more students in the course, then
  // reallocate memory to create a space for the student.
  else
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
   
  // Fill in the space created with the student. 
  course->students[course->total_students - 1] = *student;
}

/** 
 * @brief Prints out a course's information.
 *
 * @param course The course to be printed.
 */
void print_course(Course* course)
{
  //Prints course information
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
 
  //For loop, to print out every student in the course one by one.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * @brief Returns the student with the highest score in the course.
 *
 * @param course The course that is being looked at for the highest score.
 * @return Student
 */
Student* top_student(Course* course)
{

  //@brief If there are no students, then NULL.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // For loop to run through every student in the course one by one.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);

    //If the current student's average is 
    //higher than the last maximum, it is the new maximum.
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  //Return the student with the maximum average.
  return student;
}

/** 
 * @brief Returns the passing students in a course.
 *
 * @param course The course for which we are looking for passing students
 * @param total_passing Total passing students
 * @return Student 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //For loop to count how many students in the course are passing.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Creates an array of size of number of passing students.
  passing = calloc(count, sizeof(Student));

  int j = 0;

  //For loop to run through each student again.
  for (int i = 0; i < course->total_students; i++)
  {
    //If the current student's average is above 50, 
    //add them to the array of passing students.
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  //Return the passing students.
  return passing;
}