var searchData=
[
  ['first_5fname_0',['first_name',['../struct__student.html#a320c6a52b4984cd8e24726d0a264574c',1,'_student']]]
];
