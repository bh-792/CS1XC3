var searchData=
[
  ['generate_5frandom_5fstudent_0',['generate_random_student',['../student_8c.html#ad0f523c2c17c9b40389cd8031052fc85',1,'generate_random_student(int grades):&#160;student.c'],['../student_8h.html#ad0f523c2c17c9b40389cd8031052fc85',1,'generate_random_student(int grades):&#160;student.c']]],
  ['grades_1',['grades',['../struct__student.html#aa6495523ad72007cf509e024603b4127',1,'_student']]]
];
