var searchData=
[
  ['total_5fstudents_0',['total_students',['../struct__course.html#a6de820e9130cb18bb757b6f17df6c002',1,'_course']]]
];
