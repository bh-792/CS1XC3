/**
 * @file student.c
 * @author Bob He
 * @brief
 * @version 0.1
 * @date 2022-04-10
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** 
 * @brief Adds a grade to the student.
 *
 * @param student
 * @param grade
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;

  //If there is only one grade for the student, then
  //allocate a space for the grade.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  
  //If there is more than one grade for the student, then
  //reallocate to create a space for the grade.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }

  //In the allocated space, add the student's grade.
  student->grades[student->num_grades - 1] = grade;
}

/** 
 * @brief Returns the student's average grade.
 *
 * @param student
 * @return average
 */
double average(Student* student)
{
  //If there are no grades for the student, return 0.
  if (student->num_grades == 0) return 0;

  double total = 0;

  //For loop to sum up all of the student's grades, 
  //if there are more than 0.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];

  //Returns the average of the grades summed up.
  return total / ((double) student->num_grades);
}

/** 
 * @brief Prints out the student's information.
 *
 * @param student
 */
void print_student(Student* student)
{ 
  //Prints basic student information.
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  //For loop to run through all of the student's grades,
  //and print them.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  //Prints the average grade.
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * @brief Randomly generates a new student with specified number of grades.
 *
 * @param grades
 * @return Student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  //Allocates space in memory for the new student.
  Student *new_student = calloc(1, sizeof(Student));

  //Randomly generates a first and last name
  //for the student.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //For loop to randomly generate the 10 characters in the id,
  //from 0 to 9.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //For loop to generate the number of grades specified.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}